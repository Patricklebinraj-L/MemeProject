import './about.css';
import Footer from './footer';

const About = ()=>{

    return (

        <>
        <div className='about'>

            <h1> About us </h1><br/>
            <p> 

                This is the platform for meme creators, to make here some meme and meme templates
                regarding to their own demand, and also here the visitors or users may have 
                process over the media like downloading the memes, which ever done here itself
                and this is the platorm to serve whatever the commercial user actually demanded
                so that all the process of making,creating,publishing,exploring,servicing,templating
                sharing,etc...,


            </p>

        </div>

        <Footer/>

        </>


    );


}

export default About;